import AddUser from "./Components/Dashboard Components/AddUser";
import AddCategory from "./Components/Dashboard Components/AddCategory";
import AddProduct from "./Components/Dashboard Components/AddProduct";
import Dashboard from "./Components/Dashboard Components/Dashboard";
import SiderbarComponent from "./Components/Dashboard Components/SiderbarComponent";
import Login from "./Components/Login";
import Navbar from "./Components/Navbar";
import RegisterComponent from "./Components/RegisterComponent";
import { DataProvider } from "./context/Datacontext";

function App() {
  return (
    <DataProvider>
    <div className="App">
     <Login/>
    </div>
    </DataProvider>
  );
}

export default App;
