import React from 'react'
import SiderbarComponent from './Dashboard Components/SiderbarComponent'
export default function NavBarAdmin() {
  return (
    <>
    <nav className="navbar navbar-dark bg-dark fixed-top">
        <button className="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasDarkNavbar" aria-controls="offcanvasDarkNavbar">
          <span className="navbar-toggler-icon"></span>
        </button>
       
        <div className="container-fluid">
        
          <div className="offcanvas offcanvas-start text-bg-dark"  id="offcanvasDarkNavbar" aria-labelledby="offcanvasDarkNavbarLabel">
            <div className="offcanvas-header">
              <h5 className="offcanvas-title" id="offcanvasDarkNavbarLabel"></h5>
              <button type="button" className="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div className="offcanvas-body container-fluid bg-dark">
              
          <SiderbarComponent/>
            </div>
          </div>
        </div>
      </nav>
    </>
  )
}
