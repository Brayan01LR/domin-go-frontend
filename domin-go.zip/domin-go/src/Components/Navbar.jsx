import React from 'react'
import logo from "../Images/2.svg"
import "../styles/navbar.css";
import SiderbarComponent from './Dashboard Components/SiderbarComponent';
export default function Navbar() {
  return (
    <>
      <nav className="navbar navbar-expand-lg bg-dark ">
        <div className='container col-xl-3'>
          <img className="card-img-top" />
        </div>
        <div className="container-fluid col-xl-5">
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNavDropdown">
            <ul className="navbar-nav  fw-bolder">
              <li className="nav-item">
                <a className="nav-link active text-light" aria-current="page" href="#">Inicio</a>
              </li>
              <li className="nav-item">
                <a className="nav-link text-light" href="#">Contacto</a>
              </li>
              <li className="nav-item">
                <a className="nav-link text-light" href="#">Crear Negocio</a>
              </li>
              <li className="nav-item dropdown ">
                <a className="nav-link dropdown-toggle text-light" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  Acciones
                </a>
                <ul className="dropdown-menu">
                  <li><a className="dropdown-item" href="#">Reportar un problema</a></li>
                  <li><a className="dropdown-item" href="#">Solicitar accesoria</a></li>
                  <li><a className="dropdown-item" href="#">Condiciones de privacidad y uso</a></li>
                </ul>
              </li>
            </ul>
          </div>
        </div>
        <div className='container col-xl-2 ps-5'>
          <button type="button" class="btn btn-primary ms-5">Iniciar sesion</button>
        </div>
      </nav>

     
    </>
  )
}
