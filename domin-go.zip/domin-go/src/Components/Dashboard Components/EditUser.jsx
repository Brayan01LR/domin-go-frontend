import React from 'react'

export default function AddUser() {
    return (
        <form >
            <div className='container-fluid text-center mt-5 mb-4'>
                <h2>Edit user information</h2>
                <div className='container container-doble-item col-xl-5 mt-4 text-start'>
                    <div className='container col-xl-6'>
                        <label for="validationServer01" class="form-label">First name:</label>
                        <input type="text" class="form-control input-log" id="validationServer01" placeholder="Juan" required autoComplete='off' />
                        <div class="invalid-feedback">
                            Looks good!
                        </div>
                    </div>

                    <div className='container col-xl-6'>
                        <label for="exampleFormControlInput1" class="form-label">Last name:</label>
                        <input type="text" class="form-control input-log" id="exampleFormControlInput1" placeholder="Mendoza" required autoComplete='off' />
                    </div>
                </div>
                <div className='container col-xl-5 text-start mt-4'>
                    <label for="exampleFormControlInput1" class="form-label">Address:</label>
                    <input type="text" class="form-control input-log" id="exampleFormControlInput1" placeholder="Colonia flores, pasaje #1" required autoComplete='off' />
                </div>
                <div className='container col-xl-5 text-start mt-4'>
                    <label for="exampleFormControlInput1" class="form-label">Email:</label>
                    <input type="email" class="form-control input-log" id="exampleFormControlInput1" placeholder="name@example.com" required autoComplete='off' />
                </div>
                <div className='container container-doble-item text-start col-xl-5 mt-4'>
                    <div className='container col-xl-6'>
                        <label for="exampleFormControlInput1" class="form-label">Phone number:</label>
                        <input type="text" class="form-control input-log" id="exampleFormControlInput1" placeholder="0000-0000" required autoComplete='off' />
                    </div>

                    <div className='container col-xl-6'>
                        <label for="exampleFormControlInput1" class="form-label">User name:</label>
                        <input type="text" class="form-control input-log" id="exampleFormControlInput1" placeholder="falcon12" required autoComplete='off' />
                    </div>
                </div>
                <div className="container mt-4">
                    <button type="button" class="btn btn-secundary bg-dark text-light  btn-regresar px-5">Return</button>
                    <button type="submit" class="btn btn-primary ms-5 btn-login px-4">Update</button>
                </div>

            </div>
        </form>
    )
}
