/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useContext } from 'react';
import "../../styles/sb-admin-2.min.css";
import "../../styles/dashboard.css";
import DataContext from '../../context/Datacontext';

export default function SiderbarComponent() {
    const { setDashOption } = useContext(DataContext);

    return (
        <>
            <div className="wrapper w-100 h-100 ">

                <ul className="navbar-nav bg-gradient-transparent  accordion w-100" id="accordionSidebar">

                    <a className="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
                        <div className="sidebar-brand-text mx-3 text-light fs-3">Administración</div>
                    </a>

                    <hr className="sidebar-divider my-0" />

                    <li className="nav-item" onClick={() => setDashOption(0)}>
                        <a className="nav-link" href="#">
                            <i class="fa-solid fa-house"></i>
                            <span>  Dashboard</span></a>
                    </li>

                    <hr className="sidebar-divider" />

                    <div className="sidebar-heading">
                        Control
                    </div>

                    <li className="nav-item " onClick={() => setDashOption(1)}>
                        <a className="nav-link " href="#" data-target="#collapseTwo"
                            aria-expanded="true" aria-controls="collapseTwo">
                            <i class="fa-sharp fa-solid fa-plus"></i>
                            <span> Add Product</span>
                        </a>
                    </li>
                    <li className="nav-item" onClick={() => setDashOption(2)}>
                        <a className="nav-link collapsed" href="#" data-target="#collapseTwo"
                            aria-expanded="true" aria-controls="collapseTwo">
                            <i class="fa-solid fa-user"></i>
                            <span> Add User</span>
                        </a>
                    </li>
                    <li className="nav-item" onClick={() => setDashOption(3)}>
                        <a className="nav-link collapsed" href="#" data-target="#collapseTwo"
                            aria-expanded="true" aria-controls="collapseTwo">
                            <i class="fa-sharp fa-solid fa-puzzle-piece"></i>
                            <span> Add Category</span>
                        </a>
                    </li>

                    <li className="nav-item" onClick={() => setDashOption(4)}>
                        <a className="nav-link collapsed" href="#" data-target="#collapseTwo"
                            aria-expanded="true" aria-controls="collapseTwo">
                            <i class="fa-regular fa-file-powerpoint"></i>
                            <span> Add Presentation</span>
                        </a>
                    </li>
                    <li className="nav-item" onClick={() => setDashOption(5)}>
                        <a className="nav-link collapsed" href="#" data-target="#collapseTwo"
                            aria-expanded="true" aria-controls="collapseTwo">
                            <i class="fa-regular fa-copyright"></i>
                            <span> Add Brand</span>
                        </a>
                    </li>

                    <hr className="sidebar-divider" />

                    <div className="sidebar-heading">
                        Views
                    </div>

                    <li className="nav-item" onClick={() => setDashOption(6)}>
                        <a className="nav-link collapsed" href="#" data-target="#collapsePages"
                            aria-expanded="true" aria-controls="collapsePages">
                            <i class="fa-sharp fa-solid fa-eye"></i>
                            <span> View products</span>
                        </a>
                    </li>

                    <li className="nav-item" onClick={() => setDashOption(7)}>
                        <a className="nav-link" href="#">
                            <i class="fa-solid fa-users"></i>
                            <span> View Users</span></a>
                    </li>


                    <li className="nav-item" onClick={() => setDashOption(8)}>
                        <a className="nav-link " href="#">
                            <i className="fas fa-fw fa-table"></i>
                            <span> View Categories</span></a>
                    </li>
                    <li className="nav-item" onClick={() => setDashOption(9)}>
                        <a className="nav-link" href="#">
                            <i class="fa-sharp fa-solid fa-file-powerpoint"></i>
                            <span> View Presentations</span></a>
                    </li>
                    <li className="nav-item" onClick={() => setDashOption(10)}>
                        <a className="nav-link" href="#">
                            <i class="fa-solid fa-copyright"></i>
                            <span> View Brands</span></a>
                    </li>
                </ul>
                
            </div>
            
        </>

    )
}
