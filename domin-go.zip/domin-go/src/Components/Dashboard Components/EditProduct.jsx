import React from 'react'
import "../../styles/addProduct.css"
export default function AddProduct() {
    return (
        <>

            <div className='container text-center mt-5 mb-4'>
                <h2>Edit product information</h2>
                <div className='container  col-xl-8 mt-4 text-start'>
                    <div className='container col-xl-11'>
                        <label for="exampleFormControlInput1" class="form-label">Product name:</label>
                        <input type="text" class="form-control input-log" id="exampleFormControlInput1" />
                    </div>
                </div>
                <div className='container col-xl-7 text-start mt-4'>
                    <label for="exampleFormControlInput1" class="form-label">Description:</label>
                    <input type="email" class="form-control input-log" id="exampleFormControlInput1" />
                </div>
                <div className='container col-xl-7 text-start mt-4'>
                    <label for="exampleFormControlInput1" class="form-label">Image (URL)</label>
                    <input type="password" class="form-control input-log" id="exampleFormControlInput1" />
                </div>
                <div className='container col-xl-4 text-start mt-4'>
                    <label for="exampleFormControlInput1" class="form-label">Price:</label>
                    <input type="email" class="form-control input-log" id="exampleFormControlInput1" placeholder="$5.99" />
                </div>
                <div className='container container-doble-item  col-xl-7 mt-4 text-start'>

                    <div className='container col-xl-5 text-start mt-4'>
                        <label for="exampleFormControlInput1" class="form-label">Brand:</label>
                        <select class="form-select" aria-label="Default select example">
                            <option selected>Select brand</option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                    </div>
                    <div className='container col-xl-5 text-start mt-4'>
                        <label for="exampleFormControlInput1" class="form-label">Presentation:</label>
                        <select class="form-select" aria-label="Default select example">
                            <option selected>Select presentation</option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                    </div>
                    <div className='container col-xl-5 text-start mt-4'>
                        <label for="exampleFormControlInput1" class="form-label">Category:</label>
                        <select class="form-select" aria-label="Default select example">
                            <option selected>Select category</option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                    </div>
                </div>
                <div className="container mt-4">
                    <button type="button" class="btn btn-secundary bg-dark text-light  btn-regresar px-5">Return</button>
                    <button type="button" class="btn btn-primary ms-5 btn-login px-4">Update product</button>
                </div>

            </div>
        </>
    )
}
