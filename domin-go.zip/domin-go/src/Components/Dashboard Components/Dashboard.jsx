/* eslint-disable no-unused-vars */
import React from 'react'
import NavBarAdmin from '../NavBarAdmin';
// eslint-disable-next-line no-unused-vars
import SiderbarComponent from "../Dashboard Components/SiderbarComponent";
import PrincipalComponent from './PrincipalComponent';
import Navbar from '../Navbar';
export default function Dashboard() {
  return (
    <>
      <NavBarAdmin/>
      <div className='general-container'>
        <div className='container-fluid mt-5'>
          <PrincipalComponent />
        </div>
      </div>
    </>
  )
}
