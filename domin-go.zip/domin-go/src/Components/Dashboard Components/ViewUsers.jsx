import React from 'react'
import "../../styles/table.css"
export default function ViewUsers() {
    return (
        <>
            <div class="container-fluid mt-4">

                <h1 class="h3 mb-2 text-gray-800">All Users</h1>
                <p class="mb-4 fs-5">Tabla con datos de todos los usuarios registrados actualmente</p>

                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive table-users">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Full name</th>
                                        <th>Address</th>
                                        <th>User name</th>
                                        <th>Phone</th>
                                        <th>Email</th>
                                        <th>Password</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>
                                        <th>Id</th>
                                        <th>Full name</th>
                                        <th>Address</th>
                                        <th>User name</th>
                                        <th>Phone</th>
                                        <th>Email</th>
                                        <th>Password</th>
                                        <th>Actions</th>
                                    </tr>
                                </tfoot>
                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td>Brayan Adilio Rivas</td>
                                        <td>Colonia leonor, casa #5, las dispensas</td>
                                        <td>Brayan01</td>
                                        <td>77890820</td>
                                        <td>brayanadiliorivas0011@gmail.com</td>
                                        <td>Erikateamo12</td>
                                        <td className='text-center'>
                                        <button type="button" class="btn btn-danger me-2" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                                        <i className="fa-solid fa-trash"></i>
                                        </button>
                                        <div class="modal fade " id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-centered">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5" id="staticBackdropLabel">Delete User</h1>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                    <i className="fa-solid fa-trash text-danger fs-1"></i>
                                                    <br/>
                                                    <p className='fs-5'>Are you sure you want to delete this user?</p>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Delete</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                            <button type="button" class="btn btn-primary ms-1 btn-login px-3"><i className="fa-solid fa-pen-to-square"></i></button>
                                        </td>
                                    </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </>
    )
}
