import React from 'react'
import "../../styles/viewBrands.css"
export default function ViewBrands() {
  return (
    <>
    <div class="container-fluid mt-4">

<h1 class="h3 mb-2 text-gray-800">All Brands</h1>
<p class="mb-4 fs-5">Tabla con datos de todas las marcas registradas actualmente</p>

<div className='container-fluid text-center container-brands'>
<div class="card shadow mb-4 col-xl-8">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Brands Table</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive table-users pe-3">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Brand name</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                    <th>Id</th>
                        <th>Brand name</th>
                        <th>Actions</th>
                    </tr>
                </tfoot>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>Regia</td>
                       
                        <td className='text-center'>
                        <button type="button" class="btn btn-danger me-2" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                                        <i className="fa-solid fa-trash"></i>
                                        </button>
                                        <div class="modal fade " id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-centered">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5" id="staticBackdropLabel">Delete Brand</h1>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                    <i className="fa-solid fa-trash text-danger fs-1"></i>
                                                    <br/>
                                                    <p className='fs-5'>Are you sure you want to delete this brand?</p>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Delete</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                            <button type="button" class="btn btn-primary ms-1 btn-login px-3"><i className="fa-solid fa-pen-to-square"></i></button>
                        </td>
                    </tr>

                </tbody>
            </table>
        </div>
    </div>
</div>
</div>

</div>
    </>
  )
}
