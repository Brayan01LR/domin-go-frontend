import React from 'react'

export default function AddCategory() {
    return (
        <>
            <div className='container text-center mt-5 mb-4'>
                <h2>Edit Presentation</h2>
                <div className='container  col-xl-8 mt-4 text-start'>
                    <div className='container col-xl-11'>
                        <label for="exampleFormControlInput1" class="form-label">Presentation name:</label>
                        <input type="text" class="form-control input-log" id="exampleFormControlInput1" />
                    </div>
                </div>
                <div className="container mt-4">
                    <button type="button" class="btn btn-secundary bg-dark text-light  btn-regresar px-5">Return</button>
                    <button type="button" class="btn btn-primary ms-5 btn-login px-4">Update Presentation</button>
                </div>
            </div>
        </>
    )
}
