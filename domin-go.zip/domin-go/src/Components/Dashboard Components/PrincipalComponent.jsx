import React , {useContext} from 'react'
import AddUser from './AddUser';
import AddCategory from './AddCategory';
import AddProduct from './AddProduct';
import AddBrand from './AddBrand'
import AddPresentation from './AddPresentation'
import DataContext from '../../context/Datacontext';
import ViewUsers from './ViewUsers';
import ViewProducts from './ViewProducts';
import ViewBrands from './ViewBrands';
import ViewCategory from './ViewCategory';
import ViewPresentations from './ViewPresentations';
import HomeDashboard from './HomeDashboard';
import EditUser from './EditUser';
export default function PrincipalComponent() {
const {dashOption} = useContext(DataContext);

if(dashOption===0){
    return(
        <HomeDashboard/>
    )
}else if(dashOption===1){
    return(
        <AddProduct/>
    )
}else if(dashOption===2){
    return(
        <EditUser/>
    )
}
else if(dashOption===3){
    return(
        <AddCategory/>
    )
}
else if(dashOption===4){
    return(
        <AddPresentation/>
    )
}
else if(dashOption===5){
    return(
        <AddBrand/>
    )
}
else if(dashOption===6){
    return(
        <ViewProducts/>
    )
}
else if(dashOption===7){
    return(
        <ViewUsers/>
    )
}
else if(dashOption===8){
    return(
        <ViewCategory/>
    )
}
else if(dashOption===9){
    return(
        <ViewPresentations/>
    )
}
else if(dashOption===10){
    return(
        <ViewBrands/>
    )
}

}
