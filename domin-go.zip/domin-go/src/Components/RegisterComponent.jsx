import React from 'react'
import "../styles/register.css"
export default function RegisterComponent() {
    return (
        <div className='container text-center mt-4 mb-4'>
            <h2>Registro de cuenta</h2>
            <div className='container container-doble-item col-xl-5 mt-4 text-start'>
                <div className='container col-xl-6'>
                    <label for="exampleFormControlInput1" class="form-label">Nombre</label>
                    <input type="text" class="form-control input-log" id="exampleFormControlInput1" placeholder="Juan" />
                </div>

                <div className='container col-xl-6'>
                    <label for="exampleFormControlInput1" class="form-label">Apellido</label>
                    <input type="text" class="form-control input-log" id="exampleFormControlInput1" placeholder="Mendoza" />
                </div>
            </div>
            <div className='container col-xl-5 text-start mt-4'>
                <label for="exampleFormControlInput1" class="form-label">Direccion</label>
                <input type="email" class="form-control input-log" id="exampleFormControlInput1" placeholder="Colonia flores, pasaje #1" />
            </div>
            <div className='container col-xl-5 text-start mt-4'>
                <label for="exampleFormControlInput1" class="form-label">Correo electronico</label>
                <input type="email" class="form-control input-log" id="exampleFormControlInput1" placeholder="name@example.com" />
            </div>
            <div className='container col-xl-5 text-start mt-4'>
                <label for="exampleFormControlInput1" class="form-label">Contraseña</label>
                <input type="password" class="form-control input-log" id="exampleFormControlInput1" placeholder="*********" />
            </div>
            <div className='container col-xl-5 text-start mt-4'>
                <label for="exampleFormControlInput1" class="form-label">Confirmar contraseña</label>
                <input type="password" class="form-control input-log" id="exampleFormControlInput1" placeholder="*********" />
            </div>
            <div className='container container-doble-item text-start col-xl-5 mt-4'>
                <div className='container col-xl-6'>
                    <label for="exampleFormControlInput1" class="form-label">Telefono</label>
                    <input type="text" class="form-control input-log" id="exampleFormControlInput1" placeholder="0000-0000" />
                </div>

                <div className='container col-xl-6'>
                    <label for="exampleFormControlInput1" class="form-label">Nombre de usuario</label>
                    <input type="text" class="form-control input-log" id="exampleFormControlInput1" placeholder="falcon12" />
                </div>
            </div>
            <div className="container mt-4">
                <button type="button" class="btn btn-secundary bg-dark text-light  btn-regresar px-5">Regresar</button>
                <button type="button" class="btn btn-primary ms-5 btn-login px-4">Registrarme</button>
            </div>

        </div>
    )
}
