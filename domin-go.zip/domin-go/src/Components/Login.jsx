import React from 'react'
import "../styles/login.css"

export default function Login() {
  return (
    <>
   <div className="container mb-4 text-center align-middle general mt-5">
    <h2>Iniciar Sesion</h2>
    <div className='container col-xl-5 text-start mt-5'>
    <label for="exampleFormControlInput1" class="form-label">Email or Username</label>
  <input type="email" class="form-control input-log" id="exampleFormControlInput1" placeholder="name@example.com"/>
    </div>
    <div className='container col-xl-5 text-start mt-4'>
    <label for="exampleFormControlInput1" class="form-label">Contraseña</label>
  <input type="password" class="form-control input-log" id="exampleFormControlInput1" placeholder="*********"/>
    </div>
    <p className='mt-3  fs-6'>No tienes cuenta? <a className="text-primary text-register">Registrate</a></p>
    <div className="container mt-3">
    <button type="button" class="btn btn-secundary bg-dark text-light  btn-regresar px-5">Regresar</button>
    <button type="button" class="btn btn-primary ms-5 btn-login px-4">Iniciar sesion</button>
    </div>
   </div>
   </>
  )
}
