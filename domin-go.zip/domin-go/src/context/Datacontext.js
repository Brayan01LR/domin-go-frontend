import React, { createContext, useState } from 'react';



 const DataContext = createContext();

export const DataProvider = ({ children }) => {

   const [dashOption, setDashOption] = useState(0);

    return (
        <DataContext.Provider value={{
            dashOption, setDashOption
        }}>
            {children}
        </DataContext.Provider>
    )
}
export default DataContext;
